/**
 * 
 */
/**
 * 
 */
module AtvSwingLists {
	requires java.desktop;
}