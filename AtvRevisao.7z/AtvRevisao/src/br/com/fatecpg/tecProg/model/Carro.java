package br.com.fatecpg.tecProg.model;

public class Carro {
public String marca, modelo; //apenas isso....
public int ano;
}
