package br.com.fatecpg.tecProg.model;

public class Celular {
	public String marca, modelo;
	public double preco;
}
