package br.com.fatecpg.tecProg.model;

public class Livro {
public String titulo, autor;
public int anoPublicacao;
}
