package br.edu.fatecpg.tecprog.atvSwingList.model;

public class Calculadora {

	public double soma(double vl1, double vl2) {
		return vl1 + vl2;
	}

	public double multiplicacao(double vl1, double vl2) {
		return vl1 * vl2;
	}
}
